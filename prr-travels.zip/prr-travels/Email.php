<?php
$receiver = "sharitha2k@gmail.com";
$subject = "Email Test via PHP using Localhost";
$body = "Hi, .This is  haritha a test email send from Localhost.";
$sender = "From:vibrotechseo@gmail.com";

if(mail($receiver, $subject, $body, $sender)){
    echo "Email sent successfully to $receiver";
}else{
    echo "Sorry, failed while sending mail!";
}
